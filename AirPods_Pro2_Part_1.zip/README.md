# AirPods Pro 2 — Part 1

- Format: 1080×1920 vertical, 30fps
- Composition: `Main`
- Timeline duration: 30.00s
- Theme: cool minimal — background #F8FAFC, hero #6478F5, accent #67D5E8, text #172033, surface #DDE5F0.
- `public/voiceover.mp3` is included when the source audio overlaps this segment. In `src/Root.tsx`, set `ENABLE_VOICEOVER = true` to preview it. It is false by default to keep renders voiceover-free.
- SFX are included under `public/sfx/`.

## Commands
1. `npm install`
2. `npx remotion studio src/index.ts`
3. `npx remotion render src/index.ts Main out/video.mp4`

Note: the supplied detailed SRT reaches 100.65s, while the supplied narration WAV is 89.60s. Part 3 therefore has an audio gap after the supplied narration ends; verify narration timing before final export.
