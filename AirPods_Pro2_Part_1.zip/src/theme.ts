export const theme = {
  colors: { bg: "#F8FAFC", hero: "#6478F5", accent: "#67D5E8", text: "#172033", surface: "#DDE5F0", muted: "#64748B", white: "#FFFFFF" },
  fonts: { main: '"Hind Siliguri", "Noto Sans Bengali", sans-serif' },
  radius: 30,
  ease: "cubic-bezier(0.22, 1, 0.36, 1)"
};
