import React from "react";
import { AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { theme } from "./theme";

const ENABLE_VOICEOVER = false; // Studio preview: true করলে public/voiceover.mp3 চালু হবে; রেন্ডারে ডিফল্ট বন্ধ
const beats = [[0.0, 5.7, "শহরের কোলাহল", "শান্তি কি খুব দরকার?", "01"], [5.7, 11.0, "একটু শান্তি", "মনের মতো মিউজিক", "02"], [11, 16.0, "উৎসব জোন", "utsabzone.store", "03"], [16, 22.0, "AirPods Pro 2", "Active Noise Cancellation", "04"], [22, 30.0, "বাইরের শব্দ মিউট", "নিজের সুরে ডুবে যান", "05"]];
const clips = ["product_1.mp4", "product_2.mp4", "product_3.mp4"];
const totalFrames = 900;

const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const idx = Math.min(clips.length-1, Math.floor(frame / (fps*10)) % clips.length);
  const drift = Math.sin(frame/55)*18;
  return <AbsoluteFill style={{background:theme.colors.bg}}>
    <OffthreadVideo src={staticFile("media/"+clips[idx])} loop muted
      style={{width:"100%",height:"100%",objectFit:"cover",transform:`scale(1.08) translateX(${drift}px)`}} />
    <AbsoluteFill style={{background:"linear-gradient(180deg, rgba(248,250,252,.12), rgba(248,250,252,.78) 46%, rgba(248,250,252,.98) 100%)"}} />
    <div style={{position:"absolute",width:820,height:820,borderRadius:"50%",right:-320,top:-250,background:theme.colors.accent,opacity:.20,filter:"blur(80px)"}} />
  </AbsoluteFill>;
};

const Sfx: React.FC = () => {
  const {fps}=useVideoConfig();
  const entries=[0, 5.7, 11, 16, 22].map((t,i)=>({from:Math.max(0,Math.round(t*fps)-2),file:i===0?"soft-thud.wav":i===3?"chime.wav":i===4?"whoosh.wav":"pop.wav"}));
  return <>{entries.map((e,i)=><Sequence key={i} from={e.from}><Audio src={staticFile("sfx/"+e.file)} volume={0.24}/></Sequence>)}</>;
};

const BeatCard: React.FC<{beat: any; index:number}> = ({beat,index}) => {
  const frame=useCurrentFrame(); const {fps}=useVideoConfig();
  const p=spring({frame,fps,config:{damping:18,stiffness:115}});
  const opacity=interpolate(frame,[0,10],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  const float=Math.sin(frame/22)*4;
  return <AbsoluteFill style={{justifyContent:"flex-end",alignItems:"center",padding:"0 70px 220px",opacity}}>
    <div style={{width:"100%",padding:"54px 44px 60px",borderRadius:theme.radius,background:"rgba(255,255,255,.88)",border:"1px solid rgba(100,120,245,.18)",boxShadow:"0 28px 90px rgba(23,32,51,.12)",backdropFilter:"blur(18px)",transform:`translateY(${(1-p)*55+float}px) scale(${.96+p*.04})`}}>
      <div style={{fontFamily:theme.fonts.main,fontSize:24,fontWeight:700,color:theme.colors.hero,letterSpacing:0,marginBottom:18}}>UTSAB ZONE  ·  AIRPODS PRO 2</div>
      <div style={{fontFamily:theme.fonts.main,fontSize:64,fontWeight:800,lineHeight:1.12,color:theme.colors.text,letterSpacing:0}}>{beat[2]}</div>
      <div style={{fontFamily:theme.fonts.main,fontSize:34,fontWeight:600,lineHeight:1.35,color:theme.colors.muted,marginTop:22,letterSpacing:0}}>{beat[3]}</div>
      <div style={{height:8,width:190,marginTop:34,borderRadius:9,background:theme.colors.accent,transform:`scaleX(${interpolate(frame,[0,18],[.2,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})})`,transformOrigin:"left"}} />
    </div>
    <div style={{position:"absolute",top:120,left:70,fontFamily:theme.fonts.main,fontSize:28,color:theme.colors.text,fontWeight:700}}>{beat[4]} / 17</div>
    <div style={{position:"absolute",top:120,right:70,width:110,height:110,borderRadius:"50%",border:"2px solid "+theme.colors.hero,display:"flex",alignItems:"center",justifyContent:"center",color:theme.colors.hero,fontSize:28,fontWeight:800}}>AZ</div>
  </AbsoluteFill>;
};

const Main: React.FC = () => {
 const frame=useCurrentFrame(); const {fps}=useVideoConfig();
 const beatIndex=beats.findIndex((b,i)=>frame>=b[0]*fps && (i===beats.length-1 || frame<beats[i+1][0]*fps));
 const beat=beats[Math.max(0,beatIndex)];
 return <AbsoluteFill>
   <Backdrop/>
   <div style={{position:"absolute",top:0,left:0,right:0,height:12,background:theme.colors.surface}}><div style={{height:"100%",width:`${Math.min(100,frame/totalFrames*100)}%`,background:theme.colors.hero}}/></div>
   <Sequence key={beatIndex} from={Math.round(beat[0]*fps)} durationInFrames={Math.max(1,Math.round(((beatIndex===beats.length-1?30:beats[beatIndex+1][0])-beat[0])*fps))}>
      <BeatCard beat={beat} index={beatIndex}/>
   </Sequence>
   <Sfx/>
   {ENABLE_VOICEOVER && <Audio src={staticFile("voiceover.mp3")} volume={1}/>}
   <AbsoluteFill style={{pointerEvents:"none",background:"radial-gradient(ellipse at center, transparent 55%, rgba(23,32,51,.10) 100%)"}}/>
 </AbsoluteFill>;
};

export const Root: React.FC = () => <Composition id="Main" component={Main} durationInFrames={totalFrames} fps={30} width={1080} height={1920} />;
